package com.javainuse;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SBTGestingApplication {

 public static void main(String[] args) {

 SpringApplication.run(SBTGestingApplication.class, args);

 }

}