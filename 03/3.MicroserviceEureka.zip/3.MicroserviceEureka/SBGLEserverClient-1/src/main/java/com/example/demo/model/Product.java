package com.example.demo.model;



import lombok.Data;
import lombok.Setter;

@Data
@Setter
public class Product {

  private String id;

  private String name;

}